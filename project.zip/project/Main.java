import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.JOptionPane;
public class Main implements ActionListener{
    JFrame frame;
    JTextField textfield;
    JButton[] numberbutton=new JButton[16];
    JButton sopbutton,posbutton,clrbutton
            ,backk;
    JPanel panel;
    Font myfont=new Font(Font.DIALOG,Font.BOLD,25);
    public static int INPUT[]=new int[20];
    int inco1=0,inco3=0;
    public static int inco=0,inco2=0;
    Main()
    {
        frame= new JFrame(" COMPUTING KARNAUGH-MAP");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420,575);
        frame.setLayout(null);
        textfield=new JTextField();
        textfield.setBounds(50,30,300,60);
        textfield.setFont(myfont);
        textfield.setBackground(Color.white);
        textfield.setEditable(false);
        sopbutton=new JButton("SOP");
        posbutton=new JButton("POS");
        clrbutton=new JButton("CLR");
        backk=new JButton("<- Back");
        sopbutton.addActionListener(this);
        sopbutton.setFont(myfont);
        sopbutton.setBackground(Color.CYAN);
        sopbutton.setFocusable(false);
        posbutton.addActionListener(this);
        posbutton.setFont(myfont);
        posbutton.setBackground(Color.yellow);
        posbutton.setFocusable(false);
        clrbutton.addActionListener(this);
        clrbutton.setFont(myfont);
        clrbutton.setBackground(Color.magenta);
        clrbutton.setFocusable(false);
        backk.addActionListener(this);
        backk.setFont(myfont);
        backk.setBackground(Color.white);
        backk.setFocusable(false);
        for(int II=0;II<16;II++)
        {
            numberbutton[II]=new JButton(String.valueOf(II));
            numberbutton[II].addActionListener(this);
            numberbutton[II].setFont(myfont);
            numberbutton[II].setBackground(Color.white);
            numberbutton[II].setFocusable(false);
        }
        clrbutton.setBounds(50,410,100,50);
        sopbutton.setBounds(150,410,100,50);
        posbutton.setBounds(250,410,100,50);
        backk.setBounds(50,465,300,50);
        panel=new JPanel();
        panel.setBounds(50,100,300,300);
        panel.setLayout(new GridLayout(4,4,10,10));
        for(int JJ=0;JJ<16;JJ++)
        {
            panel.add(numberbutton[JJ]);
        }
        frame.add(panel);
        frame.add(clrbutton);
        frame.add(sopbutton);
        frame.add(posbutton);
        frame.add(backk);
        frame.add(textfield);
        frame.setVisible(true);
    }
    public static void main(String args[])
    {  new first();
        new Main();
    }
    public void actionPerformed(ActionEvent e)
    {
        for(int II=0;II<16;II++)
        { String S,sav1="";
            if(e.getSource()==numberbutton[II])
            {  if(inco3==1)
            {	textfield.setText("");
                inco3=2;}
                INPUT[inco++]=II;
                textfield.setText(textfield.getText().concat(" "+String.valueOf(II)));
            }
        }
        if(e.getSource()==sopbutton)
        {  if(inco3==0)
        {
            textfield.setText("ENTER DON'T CARE ");
            inco2=inco;
            inco3=1;
        }
        else
        {	sop.FX="";
            frame.setVisible(false);
            frame.dispose();
            sop.s(first.no_vari,first.svar,INPUT,inco,inco2);
            textfield.setText(textfield.getText());
        }
        }
        if(e.getSource()==posbutton)
        {  if(inco3==0)
        {
            textfield.setText("ENTER DON'T CARE ");
            inco2=inco;
            inco3=1;
        }
        else
        {    pos.FX="";
            frame.setVisible(false);
            frame.dispose();
            pos.p(first.no_vari,first.svar,INPUT,inco,inco2);
            textfield.setText(textfield.getText());
        }

        }
        if(e.getSource()==clrbutton)
        {
            textfield.setText("");
            for(int ra=0;ra<inco;ra++)
            {
                INPUT[ra]=0;
            }
            inco=0;
            inco2=0;
            inco3=0;
        }
        if(e.getSource()==backk)
        {  sop.FX="";
            pos.FX="";
            frame.setVisible(false);
            frame.dispose();
            for(int ra=0;ra<inco;ra++)
            {
                INPUT[ra]=0;
            }
            inco=0;
            inco2=0;
            inco3=0;
            new first();
            new Main();
        }


    }
}
class sop
{

    static String G1[]={"A","A`","B","B`","C","C`","D","D`","E","E`","F","F`","G","G`","H","H`","I","I`","J","J`","K","K`","L","L`","M","M`","N","N`","O","O`","P","P`","Q","Q`","R","R`","S","S`","T","T`","U","U`","V","V`","W","W`","X","X`","Y","Y`","Z","Z`"};
    static String G[]=new String[8];
    static String FX="";
    public static void s(int no_var,String svar,int INPUT[],int inco,int inco2)
    { int i,j=0,n=16,a[],f[],t,d[],flag,r[],x[][]={{1,2},{1,3},{1,4},{2,3},{2,4},{3,4}},g,U=0,E=0,Z[],K=0,D[],T=0,W[],R1[][],temp,R2[][],R3[][],T1=0,T2=0,T3=0,tem[],R4[][],T4=0,i3,i1,j1[],p,p1;
        int b[]={0,1,3,2,4,5,7,6,12,13,15,14,8,9,11,10},c[]={0,4,12,8,0},e[]={0,1,3,2,0};
        r=new int[4];
        f=new int[16];
        a=new int[16];
        d=new int[50];
        D=new int[50];
        int u[],v[],q[],w[];
        u=new int[4];
        v=new int[4];
        q=new int[4];
        w=new int[4];
        Z=new int[2];
        W=new int[32];
        R1=new int[5][8];
        R2=new int[9][4];
        R3=new int[10][2];
        tem=new int[32];
        R4=new int[16][1];
        String Fin[][];
        Scanner sc=new Scanner(System.in);
        String G3[]=new String[no_var];
        for(int G4=0;G4<no_var;G4++)
        {     G3[G4]=String.valueOf(svar.charAt(G4));
        }
        creat(no_var,G3);
        Fin=new String[16][no_var];
        j1=new int[16];
        i=0;
        a=INPUT;
        i3=inco2;
        i=inco;
        int cc=0;
        for(p=0;p<i;p++)
        { if(p>=i3)
        {  j1[cc++]=a[p];}
        }
        i1=cc;
        t=i;
        for(i=0;i<t;i++)
        {  b[a[i]]=68;
        }
        for(i=0;i<16;i++)
        {    if(b[i]==68)
        {   b[i]=1;
        }
        else
        {  b[i]=0;
        }
        }
        for(i=0;i<Math.pow(2,no_var);i++)
        {
            if(b[i]==1)
            { ++U;

            }
        }
        if(U==Math.pow(2,no_var))
        {
            for(i=0;i<Math.pow(2,no_var);i++)
            {  d[i]=a[i];
            }
            E=16;
            FX="1";
            new res(b, j1,i1,R1,R2,R3,R4,T1,T2,T3,T4,1,FX,no_var);
            return;
        }
        else
        {
            t=-1;
            int V=0;
            for (i=0;i<4;i++)
            {  p1=0;
                for(p=0;p<i1;p++)
                {
                    for(int ww=0;ww<4;ww++)
                    {     if(j1[p]==(c[i]+ww))
                    { p1+=1;}
                        if(j1[p]==(c[i+1]+ww))
                        {p1+=1;}
                    }
                }
                if(p1!=8)
                {
                    if((b[c[i]]==b[c[i]+1])&&(b[c[i]]==b[c[i]+2])&&(b[c[i]+3]==b[c[i]])&&(b[c[i+1]]==b[c[i]])&&(b[c[i+1]+1]==b[c[i]])&&(b[c[i+1]+2]==b[c[i]])&&(b[c[i+1]+3]==b[c[i]])&&(b[c[i]]==1))
                    {  E=E+8;
                        for(n=0;n<4;n++)
                        {
                            d[V++]=c[i]+n;
                            d[V++]=c[i+1]+n;
                        }
                    }
                }
                p1=0;
                for(p=0;p<i1;p++)
                {
                    for(int ww=0;ww<4;ww++)
                    {     if(j1[p]==(c[i]+ww))
                    { p1+=1;}
                        if(j1[p]==(c[i+1]+ww))
                        {p1+=1;}
                    }
                }
                if(p1!=8)
                {
                    if((b[e[i]]==b[e[i]+4])&&(b[e[i]]==b[e[i]+8])&&(b[e[i]+12]==b[e[i]])&&(b[e[i+1]]==b[e[i]])&&(b[e[i+1]+4]==b[e[i]])&&(b[e[i+1]+8]==b[e[i]])&&(b[e[i+1]+12]==b[e[i]])&&
                            (b[e[i]]==1))
                    { E=E+8;
                        for(n=0;n<16;n=n+4)
                        {
                            d[V++]=e[i]+n;
                            d[V++]=e[i+1]+n;
                        }
                    }
                }
            }
            Z=correct(d,f,E);
            t=Z[0];
            E=Z[1];
            for(i=0;i<E;i++)
            {
                R1[i/8][i%8]=d[i];
            }
            temp=E;
            T1=temp/8;
            p1=1;
            for(i=0;i<=t;i++)
            {   p1=1;
                for(p=0;p<i1;p++)
                { if(j1[p]==f[i])
                { p1=0;}
                }
                if(p1==1)
                {
                    r=binary(f[i]);
                    for(g=0;g<6;g++)
                    {   for(n=0;n<4;n++)
                    { u[n]=r[n];
                        v[n]=r[n];
                        q[n]=r[n];
                        w[n]=r[n];}
                        if(u[x[g][0]-1]==0)
                        {   u[x[g][0]-1]=1;
                        }
                        else
                        {  u[x[g][0]-1]=0;}
                        if(v[x[g][1]-1]==0)
                        {   v[x[g][1]-1]=1;}
                        else
                        {  v[x[g][1]-1]=0;}
                        if(q[x[g][0]-1]==0)
                        {   q[x[g][0]-1]=1;
                        }
                        else
                        {  q[x[g][0]-1]=0;}
                        if(q[x[g][1]-1]==0)
                        {   q[x[g][1]-1]=1;}
                        else
                        {  q[x[g][1]-1]=0;}
                        if(b[sti(u)]==b[sti(v)]&&b[sti(u)]==b[sti(q)]&&b[sti(u)]==b[sti(w)]&&b[sti(w)]==1)
                        {
                            d[E++]=sti(u);
                            d[E++]=sti(v);
                            d[E++]=sti(q);
                            d[E++]=sti(w);
                            Z=correct(d,f,E);
                            t=Z[0];
                            E=Z[1];
                            i=-1;
                            break;       }
                    }
                }
            }
            j=0;
            for(i=0;i<E;i++)
            { if(i>=temp)
            { tem[j++]=d[i];}}
            for(i=0;i<j;i++)
            {
                {R2[i/4][i%4]=tem[i];}
            }
            temp=E;
            T2=j/4;
            flag=0;
            for(i=0;i<=t;i++)
            {   p1=1;
                for(p=0;p<i1;p++)
                { if(j1[p]==f[i])
                { p1=0;}
                }
                if(p1==1)
                {
                    int F,M,R,Y,H;
                    r=binary(f[i]);
                    int z[];
                    z=new int[4];
                    for(n=0;n<4;n++)
                    { u[n]=r[n];
                        v[n]=r[n];
                        q[n]=r[n];
                        w[n]=r[n];
                        z[n]=r[n];}
                    flag=0;
                    F=swap(z,17);
                    M=swap(u,0);
                    R=swap(v,1);
                    Y=swap(q,2);
                    H=swap(w,3);
                    if(b[F]==b[M]&&b[F]==1)
                    {   d[E++]=F;
                        d[E++]=M;
                        flag=1;
                    }
                    else if(b[F]==b[R]&&b[F]==1)
                    {   d[E++]=F;
                        d[E++]=R;
                        flag=1;
                    }
                    else   if(b[F]==b[Y]&&b[F]==1)
                    {
                        d[E++]=F;
                        d[E++]=Y;
                        flag=1;
                    }
                    else     if(b[F]==b[H]&&b[F]==1)
                    {
                        d[E++]=F;
                        d[E++]=H;
                        flag=1;
                    }
                    if(flag==1)
                    {
                        Z=correct(d,f,E);
                        t=Z[0];
                        E=Z[1];
                        i=-1;
                        flag=0;
                    }
                }
            }
            Z=correct(d,f,E) ;
            t=Z[0];
            E=Z[1];
            j=0;
            for(i=0;i<E;i++)
            { if(i>=temp)
            { tem[j++]=d[i];}}
            for(i=0;i<j;i++)
            {
                {R3[i/2][i%2]=tem[i];}
            }
            temp=E;
            T3=j/2;
            for(i=0;i<=t;i++)
            {   p1=1;
                for(p=0;p<i1;p++)
                { if(j1[p]==f[i])
                { p1=0;}
                }
                if(p1==1)
                {
                    if(b[f[i]]==1)
                    {d[E++]=f[i];}
                }
            }
            j=0;
            for(i=0;i<E;i++)
            {  if(i>=temp)
            { R4[j++][0]=d[i];}}
            T4=j;
            temp=E;
            j=0;
            for(i=0;i<T1;i++)
            {    Fin[j++]=comp(R1[i],1,no_var);
            }
            for(i=0;i<T2;i++)
            {Fin[j++]=comp(R2[i],1,no_var);
            }
            for(i=0;i<T3;i++)
            {Fin[j++]=comp(R3[i],1,no_var);}
            for(i=0;i<T4;i++)
            {
                Fin[j++]=comp(R4[i],0,no_var);
            }
            for(i=0;i<j;i++)
            {  for(p=0;p<no_var;p++)
            {  if(Fin[i][p]!=null)
                FX=FX+Fin[i][p];
            }
                if(i!=(j-1))
                {FX=FX+"+";}
            }
            new res(b, j1,i1,R1,R2,R3,R4,T1,T2,T3,T4,0,FX,no_var);
            return;
        }
    }
    public static int btd(int l)
    { int o=0,rem,base=1;
        while(l>0)
        {  rem=l%10;
            o=o+rem*base;
            base=base*2;
            l=l/10;
        }
        return o;
    }
    public static int sti(int y[])
    {   String s;
        int z;
        s= Integer.toString(y[0])+ Integer.toString(y[1])+ Integer.toString(y[2])+
                Integer.toString(y[3]);
        z=Integer.parseInt(s);
        z=btd(z);
        return z;
    }
    public static  int swap(int y[],int h)
    {  int s;
        if(h<16)
        {if (y[h]==1)
        { y[h]=0;}
        else
        { y[h]=1;}}
        s=  sti(y);
        return s;
    }
    public static int[] binary (int i)
    {	int k[];
        k=new int[4];
        int rem,t=-1,j;
        while(i>0)
        {  rem=i%2;
            i=i/2;
            k[++t]=rem;
        }
        while (t!=3)
        { k[++t]=0;}
        i=0;
        j=3;
        while(i<j)
        {int g;
            g=k[i];
            k[i++]=k[j];
            k[j--]=g;
        }
        return k;}
    public static int[] correct(int d[],int f[],int E)
    {	int	t=-1,flag,O[],i,j;
        O=new int[2];
        for (i=0;i<16;i++)
        {  flag=1;
            for(j=0;j<E;j++)
            { if (i==d[j])
            {  flag=0;

            }
            }
            if (flag==1)
            {  f[++t]=i;
            }
        }
        O[0]=t;
        O[1]=E;
        return O;}
    public static String[] comp(int B[],int oo,int no_var) {
        int i, A[][]=new int[B.length][no_var],F[],P=0,c=7;
        String L[];
        L= new String[no_var];
        F=new int[16];
        for (i=0;i<B.length;i++)
        { A[i]=binary(B[i]);}
        if(no_var==4)
        {
            c=1;
        }
        else if(no_var==3)
        {
            c=3;
        }
        else
        {
            c=5;
        }
        if(oo!=0)
        {	for(i=0;i<(B.length-1);i++)
        {
            if(A[i][0]==A[i+1][0])
            {if(A[i][0]==1)
            {  F[0]=1;}
            else
            { F[0]=-1;}
                F[1]+=1;}
            if(A[i][1]==A[i+1][1])
            {if(A[i][1]==1)
            {  F[2]=1;}
            else
            { F[2]=-1;}
                F[3]+=1;}
            if(A[i][2]==A[i+1][2])
            {if(A[i][2]==1)
            {  F[4]=1;}
            else
            { F[4]=-1;}
                F[5]+=1;}
            if(A[i][3]==A[i+1][3])
            {if(A[i][3]==1)
            {  F[6]=1;}
            else
            { F[6]=-1;}
                F[7]+=1;}

        }

            for(i=c;i<16;i=i+2)
            {   if(F[i]==(B.length-1))
            {  if(F[i-1]==1)
            { L[P++]=G[i-1];
            }
            else
            {L[P++]=G[i];
            }
            }
            } }
        else
        { int j=4-no_var;
            for(i=c-1;i<8;i=i+2)
            {   if(A[0][j++]==1)
            {  L[P++]=G[i];}
            else
            {  L[P++]=G[i+1];}
            }
        }
        return L;
    }
    public static void creat(int no_var,String G3[])
    {    int k=0,j;
        j=no_var;
        while(j!=4)
        {
            G[k++]="A";
            G[k++]="A`";
            j=j+1;
        }
        for(int i=0;i<no_var;i++)
        {
            for(j=0;j<52;j++)
            {
                if(G3[i].equals(G1[j]))
                {
                    G[k++]=G1[j];
                    G[k++]=G1[j+1];
                }
            }
        }
    }
}
class pos
{

    static String G1[]={"A","A`","B","B`","C","C`","D","D`","E","E`","F","F`","G","G`","H","H`","I","I`","J","J`","K","K`","L","L`","M","M`","N","N`","O","O`","P","P`","Q","Q`","R","R`","S","S`","T","T`","U","U`","V","V`","W","W`","X","X`","Y","Y`","Z","Z`"};
    static String G[]=new String[8];
    static String FX="";
    public static void p(int no_var,String svar,int INPUT[],int inco,int inco2)
    { int i,j=0,n=16,a[],f[],t,d[],flag,r[],x[][]={{1,2},{1,3},{1,4},{2,3},{2,4},{3,4}},g,U=0,E=0,Z[],K=0,D[],T=0,W[],R1[][],temp,R2[][],R3[][],T1=0,T2=0,T3=0,tem[],R4[][],T4=0,i3,i1,j1[],p,p1;
        int b[]={0,1,3,2,4,5,7,6,12,13,15,14,8,9,11,10},c[]={0,4,12,8,0},e[]={0,1,3,2,0};
        r=new int[4];
        f=new int[16];
        a=new int[16];
        d=new int[50];
        D=new int[50];
        int u[],v[],q[],w[];
        u=new int[4];
        v=new int[4];
        q=new int[4];
        w=new int[4];
        Z=new int[2];
        W=new int[32];
        R1=new int[5][8];
        R2=new int[9][4];
        R3=new int[10][2];
        tem=new int[32];
        R4=new int[16][1];
        String Fin[][];
        Scanner sc=new Scanner(System.in);
        String G3[]=new String[no_var];
        for(int G4=0;G4<no_var;G4++)
        {     G3[G4]=String.valueOf(svar.charAt(G4));
        }
        creat(no_var,G3);
        Fin=new String[16][no_var];
        j1=new int[16];
        i=0;
        a=INPUT;
        i3=inco2;
        i=inco;
        int cc=0;
        for(p=0;p<i;p++)
        { if(p>=i3)
        {  j1[cc++]=a[p];}
        }
        i1=cc;
        t=i;
        for(i=0;i<t;i++)
        {  b[a[i]]=68;
        }
        for(i=0;i<16;i++)
        {    if(b[i]==68)
        {   b[i]=0;
        }
        else
        {  b[i]=1;
        }
        }
        for(i=0;i<Math.pow(2,no_var);i++)
        {
            if(b[i]==0)
            { ++U;

            }
        }
        if(U==Math.pow(2,no_var))
        {
            for(i=0;i<Math.pow(2,no_var);i++)
            {  d[i]=a[i];
            }
            E=16;
            FX="0";
            new res(b, j1,i1,R1,R2,R3,R4,T1,T2,T3,T4,1,FX,no_var);
            return;
        }
        else
        {
            t=-1;
            int V=0;
            for (i=0;i<4;i++)
            {  p1=0;
                for(p=0;p<i1;p++)
                {
                    for(int ww=0;ww<4;ww++)
                    {     if(j1[p]==(c[i]+ww))
                    { p1+=1;}
                        if(j1[p]==(c[i+1]+ww))
                        {p1+=1;}
                    }
                }
                if(p1!=8)
                {
                    if((b[c[i]]==b[c[i]+1])&&(b[c[i]]==b[c[i]+2])&&(b[c[i]+3]==b[c[i]])&&(b[c[i+1]]==b[c[i]])&&(b[c[i+1]+1]==b[c[i]])&&(b[c[i+1]+2]==b[c[i]])&&(b[c[i+1]+3]==b[c[i]])&&(b[c[i]]==0))
                    {  E=E+8;
                        for(n=0;n<4;n++)
                        {
                            d[V++]=c[i]+n;
                            d[V++]=c[i+1]+n;
                        }
                    }
                }
                p1=0;
                for(p=0;p<i1;p++)
                {
                    for(int ww=0;ww<4;ww++)
                    {     if(j1[p]==(c[i]+ww))
                    { p1+=1;}
                        if(j1[p]==(c[i+1]+ww))
                        {p1+=1;}
                    }
                }
                if(p1!=8)
                {
                    if((b[e[i]]==b[e[i]+4])&&(b[e[i]]==b[e[i]+8])&&(b[e[i]+12]==b[e[i]])&&(b[e[i+1]]==b[e[i]])&&(b[e[i+1]+4]==b[e[i]])&&(b[e[i+1]+8]==b[e[i]])&&(b[e[i+1]+12]==b[e[i]])&&
                            (b[e[i]]==0))
                    { E=E+8;
                        for(n=0;n<16;n=n+4)
                        {
                            d[V++]=e[i]+n;
                            d[V++]=e[i+1]+n;
                        }
                    }
                }
            }
            Z=correct(d,f,E);
            t=Z[0];
            E=Z[1];
            for(i=0;i<E;i++)
            {
                R1[i/8][i%8]=d[i];
            }
            temp=E;
            T1=temp/8;
            p1=1;
            for(i=0;i<=t;i++)
            {   p1=1;
                for(p=0;p<i1;p++)
                { if(j1[p]==f[i])
                { p1=0;}
                }
                if(p1==1)
                {
                    r=binary(f[i]);
                    for(g=0;g<6;g++)
                    {   for(n=0;n<4;n++)
                    { u[n]=r[n];
                        v[n]=r[n];
                        q[n]=r[n];
                        w[n]=r[n];}
                        if(u[x[g][0]-1]==0)
                        {   u[x[g][0]-1]=1;
                        }
                        else
                        {  u[x[g][0]-1]=0;}
                        if(v[x[g][1]-1]==0)
                        {   v[x[g][1]-1]=1;}
                        else
                        {  v[x[g][1]-1]=0;}
                        if(q[x[g][0]-1]==0)
                        {   q[x[g][0]-1]=1;
                        }
                        else
                        {  q[x[g][0]-1]=0;}
                        if(q[x[g][1]-1]==0)
                        {   q[x[g][1]-1]=1;}
                        else
                        {  q[x[g][1]-1]=0;}
                        if(b[sti(u)]==b[sti(v)]&&b[sti(u)]==b[sti(q)]&&b[sti(u)]==b[sti(w)]&&b[sti(w)]==0)
                        {
                            d[E++]=sti(u);
                            d[E++]=sti(v);
                            d[E++]=sti(q);
                            d[E++]=sti(w);
                            Z=correct(d,f,E);
                            t=Z[0];
                            E=Z[1];
                            i=-1;
                            break;       }
                    }
                }
            }
            j=0;
            for(i=0;i<E;i++)
            { if(i>=temp)
            { tem[j++]=d[i];}}
            for(i=0;i<j;i++)
            {
                {R2[i/4][i%4]=tem[i];}
            }
            temp=E;
            T2=j/4;
            flag=0;
            for(i=0;i<=t;i++)
            {   p1=1;
                for(p=0;p<i1;p++)
                { if(j1[p]==f[i])
                { p1=0;}
                }
                if(p1==1)
                {
                    int F,M,R,Y,H;
                    r=binary(f[i]);
                    int z[];
                    z=new int[4];
                    for(n=0;n<4;n++)
                    { u[n]=r[n];
                        v[n]=r[n];
                        q[n]=r[n];
                        w[n]=r[n];
                        z[n]=r[n];}
                    flag=0;
                    F=swap(z,17);
                    M=swap(u,0);
                    R=swap(v,1);
                    Y=swap(q,2);
                    H=swap(w,3);
                    if(b[F]==b[M]&&b[F]==0)
                    {   d[E++]=F;
                        d[E++]=M;
                        flag=1;
                    }
                    else if(b[F]==b[R]&&b[F]==0)
                    {   d[E++]=F;
                        d[E++]=R;
                        flag=1;
                    }
                    else   if(b[F]==b[Y]&&b[F]==0)
                    {
                        d[E++]=F;
                        d[E++]=Y;
                        flag=1;
                    }
                    else     if(b[F]==b[H]&&b[F]==0)
                    {
                        d[E++]=F;
                        d[E++]=H;
                        flag=1;
                    }
                    if(flag==1)
                    {
                        Z=correct(d,f,E);
                        t=Z[0];
                        E=Z[1];
                        i=-1;
                        flag=0;
                    }
                }
            }
            Z=correct(d,f,E) ;
            t=Z[0];
            E=Z[1];
            j=0;
            for(i=0;i<E;i++)
            { if(i>=temp)
            { tem[j++]=d[i];}}
            for(i=0;i<j;i++)
            {
                {R3[i/2][i%2]=tem[i];}
            }
            temp=E;
            T3=j/2;
            for(i=0;i<=t;i++)
            {   p1=1;
                for(p=0;p<i1;p++)
                { if(j1[p]==f[i])
                { p1=0;}
                }
                if(p1==1)
                {
                    if(b[f[i]]==0)
                    {d[E++]=f[i];}
                }
            }
            j=0;
            for(i=0;i<E;i++)
            {  if(i>=temp)
            { R4[j++][0]=d[i];}}
            T4=j;
            temp=E;
            j=0;
            for(i=0;i<T1;i++)
            {    Fin[j++]=comp(R1[i],1,no_var);
            }
            for(i=0;i<T2;i++)
            {Fin[j++]=comp(R2[i],1,no_var);
            }
            for(i=0;i<T3;i++)
            {Fin[j++]=comp(R3[i],1,no_var);}
            for(i=0;i<T4;i++)
            {
                Fin[j++]=comp(R4[i],0,no_var);
            }
            for(i=0;i<j;i++)
            {  FX=FX+"(";
                for(p=0;p<no_var;p++)
                {  if(Fin[i][p]!=null)
                {FX=FX+Fin[i][p]+"+";  }
                }
                FX=FX.substring(0,FX.length()-1);
                FX=FX+")" ;
            }
            new res(b, j1,i1,R1,R2,R3,R4,T1,T2,T3,T4,0,FX,no_var);
            return ;
        }
    }
    public static int btd(int l)
    { int o=0,rem,base=1;
        while(l>0)
        {  rem=l%10;
            o=o+rem*base;
            base=base*2;
            l=l/10;
        }
        return o;
    }
    public static int sti(int y[])
    {   String s;
        int z;
        s= Integer.toString(y[0])+ Integer.toString(y[1])+ Integer.toString(y[2])+
                Integer.toString(y[3]);
        z=Integer.parseInt(s);
        z=btd(z);
        return z;
    }
    public static  int swap(int y[],int h)
    {  int s;
        if(h<16)
        {if (y[h]==1)
        { y[h]=0;}
        else
        { y[h]=1;}}
        s=  sti(y);
        return s;
    }
    public static int[] binary (int i)
    {	int k[];
        k=new int[4];
        int rem,t=-1,j;
        while(i>0)
        {  rem=i%2;
            i=i/2;
            k[++t]=rem;
        }
        while (t!=3)
        { k[++t]=0;}
        i=0;
        j=3;
        while(i<j)
        {int g;
            g=k[i];
            k[i++]=k[j];
            k[j--]=g;
        }
        return k;}
    public static int[] correct(int d[],int f[],int E)
    {	int	t=-1,flag,O[],i,j;
        O=new int[2];
        for (i=0;i<16;i++)
        {  flag=1;
            for(j=0;j<E;j++)
            { if (i==d[j])
            {  flag=0;

            }
            }
            if (flag==1)
            {  f[++t]=i;
            }
        }
        O[0]=t;
        O[1]=E;
        return O;}
    public static String[] comp(int B[],int oo,int no_var) {
        int i, A[][]=new int[B.length][no_var],F[],P=0,c=7;
        String L[];
        L= new String[no_var];
        F=new int[16];
        for (i=0;i<B.length;i++)
        { A[i]=binary(B[i]);}
        if(no_var==4)
        {
            c=1;
        }
        else if(no_var==3)
        {
            c=3;
        }
        else
        {
            c=5;
        }
        if(oo!=0)
        {	for(i=0;i<(B.length-1);i++)
        {
            if(A[i][0]==A[i+1][0])
            {if(A[i][0]==0)
            {  F[0]=1;}
            else
            { F[0]=-1;}
                F[1]+=1;}
            if(A[i][1]==A[i+1][1])
            {if(A[i][1]==0)
            {  F[2]=1;}
            else
            { F[2]=-1;}
                F[3]+=1;}
            if(A[i][2]==A[i+1][2])
            {if(A[i][2]==0)
            {  F[4]=1;}
            else
            { F[4]=-1;}
                F[5]+=1;}
            if(A[i][3]==A[i+1][3])
            {if(A[i][3]==0)
            {  F[6]=1;}
            else
            { F[6]=-1;}
                F[7]+=1;}

        }

            for(i=c;i<16;i=i+2)
            {   if(F[i]==(B.length-1))
            {  if(F[i-1]==0)
            { L[P++]=G[i-1];
            }
            else
            {L[P++]=G[i];
            }
            }
            } }
        else
        { int j=4-no_var;
            for(i=c-1;i<8;i=i+2)
            {   if(A[0][j++]==0)
            {  L[P++]=G[i];}
            else
            {  L[P++]=G[i+1];}
            }
        }
        return L;
    }
    public static void creat(int no_var,String G3[])
    {    int k=0,j;
        j=no_var;
        while(j!=4)
        {
            G[k++]="A";
            G[k++]="A`";
            j=j+1;
        }
        for(int i=0;i<no_var;i++)
        {
            for(j=0;j<52;j++)
            {
                if(G3[i].equals(G1[j]))
                {
                    G[k++]=G1[j];
                    G[k++]=G1[j+1];
                }
            }
        }
    }
}
class  first
{ public static int no_vari;
    public static String svar;

    first()
    {
        no_vari=Integer.parseInt(JOptionPane.showInputDialog("ENTER NUMBER OF VARIABLE :"));
        svar=JOptionPane.showInputDialog("ENTER VARIABLE :");
    }
}
class res implements ActionListener
{
    JFrame fra;
    JButton bac,back;
    JPanel pan;
    JTextArea lab;
    res(int b[],int j1[],int cc,int R1[][],int R2[][],int R3[][],int R4[][],int T1,int T2,int T3,int T4,int con,String FX,int no_var)
    {   int r[]={0,1,3,2,4,5,7,6,12,13,15,14,8,9,11,10};
        String S1[]={"0","1"},S2[]={"","00","01","11","10"};
        JButton[] numbutton=new JButton[16];
        JButton[] trans=new JButton[14];
        Font myfont=new Font(Font.DIALOG,Font.BOLD,25);
        fra= new JFrame(" RESULT");
        fra.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fra.setSize(430,550);
        fra.setLayout(null);
        bac=new JButton("RESTART");
        bac.addActionListener(this);
        bac.setFont(myfont);
        bac.setBackground(Color.white);
        bac.setFocusable(false);
        back=new JButton("<- Back");
        back.addActionListener(this);
        back.setFont(myfont);
        back.setBackground(Color.white);
        back.setFocusable(false);
        for(int i=0;i<16;i++)
        {
            numbutton[i]=new JButton(String.valueOf(b[i]));
        }
        for(int i=0;i<5;i++)
        {
            trans[i]=new JButton(S2[i]);
            trans[i].setFont(myfont);
            trans[i].setBorder(null);
            trans[i].setBorderPainted(false);
            trans[i].setContentAreaFilled(false);
            trans[i].setOpaque(false);
        }
        for(int i=5;i<7;i++)
        {
            trans[i]=new JButton(S1[i-5]);
            trans[i].setFont(myfont);
            trans[i].setBorder(null);
            trans[i].setBorderPainted(false);
            trans[i].setContentAreaFilled(false);
            trans[i].setOpaque(false);
            trans[i].setFocusable(false);
        }
        for(int i=7;i<12;i++)
        {
            trans[i]=new JButton(S2[i-7]);
            trans[i].setFont(myfont);
            trans[i].setBorder(null);
            trans[i].setBorderPainted(false);
            trans[i].setContentAreaFilled(false);
            trans[i].setOpaque(false);
        }
        for(int i=12;i<14;i++)
        {
            trans[i]=new JButton(S1[i-12]);
            trans[i].setFont(myfont);
            trans[i].setBorder(null);
            trans[i].setBorderPainted(false);
            trans[i].setContentAreaFilled(false);
            trans[i].setOpaque(false);
            trans[i].setFocusable(false);
        }

        for(int j=0;j<cc;j++)
        {
            numbutton[j1[j]].setText("X");
        }
        for(int II=0;II<16;II++)
        {
            numbutton[II].setFont(myfont);
            numbutton[II].setBackground(Color.white);
            numbutton[II].setFocusable(false);
        }
        if(con==1)
        {
            for(int p=0;p<16;p++)
            {
                numbutton[p].setBackground(Color.CYAN);
            }
        }
        else
        {
            for(int k=0;k<T1;k++)
            { for(int l=0;l<8;l++)
            {  numbutton[R1[k][l]].setBackground(Color.yellow);
            }
            }
            for(int k=0;k<T2;k++)
            {for(int l=0;l<4;l++)
            {    numbutton[R2[k][l]].setBackground(Color.blue.darker().darker());
            }
            }
            for(int k=0;k<T3;k++)
            {for(int l=0;l<2;l++)
            {    numbutton[R3[k][l]].setBackground(Color.red.darker());
            }
            }
            for(int k=0;k<T4;k++)
            {for(int l=0;l<1;l++)
            {    numbutton[R4[k][l]].setBackground(Color.CYAN);
            }
            }
            for(int k=0;k<T1;k++)
            {
                for(int l=0;l<8;l++)
                {
                    for(int i =0;i<T2;i++)
                    {
                        for(int j=0;j<4;j++)
                        {
                            if(R1[k][l]==R2[i][j])
                            {
                                numbutton[R1[k][l]].setBackground(Color.green.darker().darker());
                            }
                        }
                    }
                }
            }
            for(int k=0;k<T1;k++)
            {
                for(int l=0;l<8;l++)
                {
                    for(int i =0;i<T3;i++)
                    {
                        for(int j=0;j<2;j++)
                        {
                            if(R1[k][l]==R3[i][j])
                            {
                                numbutton[R1[k][l]].setBackground(Color.orange.darker());
                            }
                        }
                    }
                }
            }
            for(int k=0;k<T2;k++)
            {
                for(int l=0;l<4;l++)
                {
                    for(int i =0;i<T3;i++)
                    {
                        for(int j=0;j<2;j++)
                        {
                            if(R2[k][l]==R3[i][j])
                            {
                                numbutton[R2[k][l]].setBackground(Color.magenta.darker().darker().darker().darker());
                            }
                        }
                    }
                }
            }
            for(int k=0;k<T2;k++)
            {
                for(int l=0;l<4;l++)
                {
                    for(int i =0;i<T3;i++)
                    {
                        for(int j=0;j<2;j++)
                        {
                            for(int p=0;p<T1;p++)
                            {
                                for(int q=0;q<8;q++)
                                {
                                    if(R2[k][l]==R3[i][j]&&R2[k][l]==R1[p][q])
                                    {
                                        numbutton[R1[k][l]].setBackground(Color.black.brighter());
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        pan=new JPanel();
        if(no_var==4)
        {  pan.setBounds(50,25,300,300);
            pan.setLayout(new GridLayout(5,5,0,0));
        }
        if(no_var==3)
        {  pan.setBounds(50,25,300,180);
            pan.setLayout(new GridLayout(3,5,0,0));
        }
        if(no_var==2)
        {  pan.setBounds(50,25,200,200);
            pan.setLayout(new GridLayout(3,3,0,0));
        }
        if(no_var==4||no_var==3)
        { for(int i=0;i<5;i++)
        {
            pan.add(trans[i]);
        }
        }
        if(no_var==2)
        {
            pan.add(trans[0]);
            pan.add(trans[5]);
            pan.add(trans[6]);
        }
        int u=8,u1=12;
        int rag[]={0,1,3,2};
        int ven=0;
        for(int JJ=0;JJ<16;JJ++)
        {  if(no_var==4&&(JJ)%4==0)
        {
            pan.add(trans[u++]);
        }
            if(((no_var==3)&&(JJ%4==0)&&(JJ<8))||((no_var==2)&&(JJ%2==0)&&(JJ<3)))
            {
                pan.add(trans[u1++]);
            }
            if(JJ<Math.pow(2,no_var))
            {   if(no_var==2)
                {
                pan.add(numbutton[r[rag[ven++]]]);
                }
                else
                {
                  pan.add(numbutton[r[JJ]]);
                }
            }
        }
        bac.setBounds(25,450,175,50);
        back.setBounds(200,450,150,50);
        fra.add(pan);
        lab=new JTextArea(FX);
        lab.setBounds(10,345,400,100);
        lab.setFont(myfont);
        lab.setLineWrap(true);
        lab.setWrapStyleWord(true);
        lab.setEditable(false);
        fra.add(lab);
        fra.add(bac);
        fra.add(back);
        fra.setVisible(true);
    }
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==bac)
        {
            fra.setVisible(false);
            fra.dispose();
            for(int ra=0;ra<Main.inco;ra++)
            {
                Main.INPUT[ra]=0;
            }
            Main.inco=0;
            Main.inco2=0;

            new first();
            new Main();
        }
        if(e.getSource()==back)
        {
            fra.setVisible(false);
            fra.dispose();
            for(int ra=0;ra<Main.inco;ra++)
            {
                Main.INPUT[ra]=0;
            }
            Main.inco=0;
            Main.inco2=0;
            new Main();
        }

    }
}